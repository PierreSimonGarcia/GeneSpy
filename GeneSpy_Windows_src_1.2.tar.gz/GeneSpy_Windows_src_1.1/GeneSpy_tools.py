#! /usr/bin/python2.7
# -*- coding: utf-8 -*-

"""
Convert_IDs function allows to extract IDs in the GeneSpy format from another format.
Example:

Original line : 484770_000725345_1_Psp_@WP_038667413_1
Formated line : 000725345.1#WP_038667413

This function takes in argument the initial string and returns a string containing
the formated IDs <Assembly>#<Accession>.
"""

def Convert_IDs(string_id):
    string_id_genespy_format = ""
    try:
        "# this code is the adaptative part that has to be edited according to your needs #"
        accession_version = string_id.split("@")[1].split("_")
        version = accession_version.pop()
        accession = "_".join(accession_version)
        assembly = string_id.split("_")[1]+"."+string_id.split("_")[2]
        string_id_genespy_format = assembly+"#"+accession+"."+version
        " #######################"
        return string_id_genespy_format
    except:
        return string_id
