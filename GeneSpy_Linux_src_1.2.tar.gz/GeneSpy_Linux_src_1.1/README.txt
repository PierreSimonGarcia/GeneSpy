######## Installation of GeneSpy ########



######## Source code ##########

0\Python:
	If you don't have python:
		https://www.python.org/downloads/release/python-2714/
		
1\Librairies:
		> open setup.py with python

2\Execution:
		> open GeneSpy.py with python	

##########################

WARNING : PATH of GeneSpy and databases should not contain any special character.

##########################
