# -*- coding: utf-8 -*-
import os
import subprocess
import platform
import sys
### necessité d'installer la version 2.7
v = sys.version_info
if v[0]!=2 or v[1]!=7:
    raw_input("Please install python2.7 (https://www.python.org/downloads/release/python-2714/\nPress Enter to exit.")
    sys.exit()






if platform.system() == "Linux":
    ### pip installé par défaut sur version Linux
    ### Tkinter pas installé sur la version Linux
    ### pas de gestion de proxy pour linux
    tab_link =  os.path.realpath(sys.argv[0]).split("/")
    prog_link = tab_link.pop()
    path_anfile_g = "/".join(tab_link)+"/"
    path_path = "/".join(tab_link)+"/PATHS_PARAMS.ini"
    if os.path.isfile(path_path) is False:
        # print path_path
        sys.exit("ERROR : PATHS_PARAMS.ini not found in GeneSpy repertory")
    pathr = open(path_path)
    PATH = []
    patht = pathr.readlines()
    pathr.close()
    for l in patht:
        if l.find("#")==-1:
            PATH.append(l.split("\t")[1].rstrip())

    prox = PATH[6]
    print "INFO: proxy parameters are not managed by setup under Linux distribution\nIf you have a proxy, please change http_proxy/https_proxy variables"
    try:
        import matplotlib
        print "INFO: Matplotlib already installed."
    except ImportError:
        try:
            print "INFO: Trying to install matplotlib using apt-get"
            cmd = subprocess.call("sudo apt-get install python-matplotlib",shell=True)
            if cmd == 0:
                print "SUCCESS: Installation of matplotlib completed."
            else:
                sys.exit("ERROR: Impossible to install Matplotlib. Check your connection or open appropriate port of your proxy.")
        except OSError:
            try:
                print "INFO: Trying to install matplotlib using yum"
                cmd = subprocess.call("sudo yum install python-matplotlib",shell=True)
                if cmd == 0:
                    print "SUCCESS: Installation of matplotlib completed."
                else:
                    sys.exit("ERROR: Impossible to install Matplotlib. Check your connection or open appropriate port of your proxy.")
            except OSError:
                try:
                    print "INFO: Trying to install matplotlib using dnf"
                    cmd = subprocess.call("sudo dnf install python2-matplotlib",shell=True)
                    if cmd == 0:
                        print "SUCCESS: Installation of matplotlib completed."
                    else:
                        sys.exit("ERROR: Impossible to install Matplotlib. Check your connection or open appropriate port of your proxy.")
                except OSError:
                    try:
                        print "INFO: Trying to install matplotlib using pacman"
                        cmd = subprocess.call("sudo pacman -S python-matplotlib",shell=True)
                        if cmd == 0:
                            print "SUCCESS: Installation of matplotlib completed."
                        else:
                            sys.exit("ERROR: Impossible to install Matplotlib. Check your connection or open appropriate port of your proxy.")
                    except OSError:
                        sys.exit("ERROR: Impossible to install Matplotlib.")
    try:
        import Tkinter
        print "INFO: Tkinter already installed."
    except ImportError:
            try:
                print "INFO: Trying to install Tkinter using apt-get"
                cmd = subprocess.call("sudo apt-get install python-tk python-imaging-tk",shell=True)
                if cmd == 0:
                    print "SUCCESS: Installation of Tkinter completed."
                else:
                    sys.exit("ERROR: Impossible to install Tkinter. Check your connection or open appropriate port of your proxy.")
            except OSError:
                try:
                    print "INFO: Trying to install Tkinter using yum"
                    cmd = subprocess.call("sudo yum install tkinter",shell=True)
                    if cmd == 0:
                        print "SUCCESS: Installation of Tkinter completed."
                    else:
                        sys.exit("ERROR: Impossible to install Tkinter. Check your connection or open appropriate port of your proxy.")
                except OSError:
                    try:
                        print "INFO: Trying to install Tkinter using dnf"
                        cmd = subprocess.call("sudo dnf install python2-tkinter",shell=True)
                        if cmd == 0:
                            print "SUCCESS: Installation of Tkinter completed."
                        else:
                            sys.exit("ERROR: Impossible to install Tkinter. Check your connection or open appropriate port of your proxy.")
                    except OSError:
                        try:
                            print "INFO: Trying to install Tkinter using pacman"
                            cmd = subprocess.call("sudo pacman -S tk",shell=True)
                            if cmd == 0:
                                print "SUCCESS: Installation of Tkinter completed."
                            else:
                                sys.exit("ERROR: Impossible to install Tkinter. Check your connection or open appropriate port of your proxy.")
                        except OSError:
                            sys.exit("ERROR: Impossible to install Tkinter.")

if platform.system() == "Windows":
    ### pip installé par défaut sur version windows
    ### setuptools pas systematiquement sur la version Windows
    ### Tkinter installé sur la version windows
    ### il manque donc que Matplotlib que l'on récup par pip
    ### gestion du proxy avec ou sans login
    tab_link =  os.path.realpath(sys.argv[0]).split("\\")
    prog_link = tab_link.pop()
    path_anfile_g = "\\".join(tab_link)+"\\"
    path_path = "\\".join(tab_link)+"\\PATHS_PARAMS.ini"
    if os.path.isfile(path_path) is False:
        # print path_path
        sys.exit("ERROR : PATHS_PARAMS.ini not found in GeneSpy repertory")
    pathr = open(path_path)
    PATH = []
    patht = pathr.readlines()
    pathr.close()
    for l in patht:
        if l.find("#")==-1:
            PATH.append(l.split("\t")[1].rstrip())

    prox = PATH[6]
    pathpyth = str(os.path.dirname(sys.executable).rstrip())+"\\python.exe"
    try:
        import matplotlib
        print "INFO: Matplotlib already installed."
    except ImportError:
        var1 = pathpyth+" -m pip install -U pip setuptools"
        var2 = pathpyth+" -m pip install matplotlib"
        if prox == "":
            try:
                print "INFO: Trying to install matplotlib using pip"
                subprocess.call(var1,shell=False)
                cmd = subprocess.call(var2,shell=False)
                if cmd == 0:
                    print "SUCCESS: Installation of Matplotlib completed."
                else:
                    print "ERROR: Impossible to install Matplotlib. Check connection/proxy adress."
                    a = raw_input("Press enter to quit")
                    sys.exit()
            except:
                print "ERROR: Impossible to install Matplotlib. Check connection/proxy adress."
                a = raw_input("Press enter to quit")
                sys.exit()
        else:
            prox_exp = "set HTTP_PROXY="+prox
            # prox_exp2 = "set HTTPS_PROXY="+prox
            try:
                print "INFO: Trying to install matplotlib using pip (proxy)"
                subprocess.call(prox_exp+" & "+var1,shell=True)
                cmd = subprocess.call(prox_exp+" & "+var2,shell=True)
                if cmd == 0:
                    print "SUCCESS: Installation of Matplotlib completed."
                else:
                    print "ERROR: Impossible to install Matplotlib. Check connection/proxy adress."
                    a = raw_input("Press enter to quit")
                    sys.exit()
            except OSError:
                print "ERROR: Impossible to install Matplotlib. Check connection/proxy adress."
                a = raw_input("Press enter to quit")
                sys.exit()



if platform.system() == "Darwin":
    ### pip pas installé par défaut sur version mac
    ### Tkinter installé sur la version mac
    ### matplotlib pas installé par défaut sur version mac
    ### gestion du proxy avec ou sans login
    #subprocess.call("alias python=\"python2.7\"",shell=True)
    tab_link =  os.path.realpath(sys.argv[0]).split("/")
    prog_link = tab_link.pop()
    path_anfile_g = "/".join(tab_link)+"/"
    path_path = "/".join(tab_link)+"/PATHS_PARAMS.ini"
    if os.path.isfile(path_path) is False:
        # print path_path
        sys.exit("ERROR : PATHS_PARAMS.ini not found in GeneSpy repertory")
    pathr = open(path_path)
    PATH = []
    patht = pathr.readlines()
    pathr.close()
    for l in patht:
        if l.find("#")==-1:
            PATH.append(l.split("\t")[1].rstrip())

    prox = PATH[6]
    try:
        import matplotlib
        print "INFO: Matplotlib already installed."
    except ImportError:
        print "INFO: Matplotlib not installed"
        if prox == "":
            try:
                import pip
                print "INFO: Pip already installed."
                # print "INFO: Trying to install upgrade pip"
                # cmd = subprocess.call("curl https://bootstrap.pypa.io/get-pip.py | python",shell=True)
                # if cmd == 0:
                #     print "SUCCESS: Pip upgraded."
                # else:
                #     print "ERROR: Impossible to upgrade pip."
                try:
                    print "INFO: Trying to install matplotlib using pip"
                    cmd = subprocess.call("python2.7 -m pip install matplotlib --user",shell=True)
                    if cmd == 0:
                        print "SUCCESS: Installation of matplotlib completed."
                    else:
                        print "ERROR: Impossible to install Matplotlib. Check connection/proxy adress/pip version."
                        a = raw_input("Press enter to quit")
                        sys.exit()
                except:
                    print "ERROR: Impossible to install Matplotlib. Check connection/proxy adress."
                    a = raw_input("Press enter to quit")
                    sys.exit()
            except ImportError:
                print "INFO: Pip not installed"
                try:
                    print "INFO: Trying to install xcode-select"
                    cmd = subprocess.call("xcode-select --install",shell=True)
                    if cmd == 0:
                        print "SUCCESS: Installation of xcode-select completed."
                    else:
                        print "WARNING: Impossible to install xcode-select. Check your connection."
                except OSError:
                    print "WARNING: Impossible to install xcode-select."
                try:
                    print "INFO: Trying to install pip using easy_install"
                    cmd = subprocess.call("sudo easy_install pip",shell=True)
                    if cmd == 0:
                        print "SUCCESS: Installation of pip completed."
                    else:
                        print "ERROR: Impossible to install pip. Check your connection."
                        # print "ERROR: Impossible to install Matplotlib. Check connection/proxy adress."
                        a = raw_input("Press enter to quit")
                        sys.exit()
                except OSError:
                    print "ERROR: Impossible to install pip"
                    a = raw_input("Press enter to quit")
                    sys.exit()
                try:
                    # print "INFO: Trying to install upgrade pip"
                    # cmd = subprocess.call("curl https://bootstrap.pypa.io/get-pip.py | python",shell=True)
                    # if cmd == 0:
                    #     print "SUCCESS: Pip upgraded."
                    # else:
                    #     print "ERROR: Impossible to upgrade pip."
                    print "INFO: Trying to install matplotlib using pip"
                    cmd = subprocess.call("python2.7 -m pip install matplotlib --user",shell=True)
                    if cmd == 0:
                        print "SUCCESS: Installation of matplotlib completed."
                    else:
                        print "ERROR: Impossible to install Matplotlib. Check connection/proxy adress/pip version."
                        a = raw_input("Press enter to quit")
                        sys.exit()
                except:
                    print "ERROR: Impossible to install Matplotlib. Check connection/proxy adress."
                    a = raw_input("Press enter to quit")
                    sys.exit()
        else:
            prox_exp = "export http_proxy="+prox
            #prox_exp2 = "export https_proxy="+prox
            try:
                import pip
                print "INFO: Pip already installed."
                try:
                    # print "INFO: Trying to install upgrade pip (proxy)"
                    # cmd = subprocess.call(prox_exp+" ; curl https://bootstrap.pypa.io/get-pip.py | python",shell=True)
                    # if cmd == 0:
                    #     print "SUCCESS: Pip upgraded."
                    # else:
                    #     print "ERROR: Impossible to upgrade pip."
                    print "INFO: Trying to install matplotlib using pip (proxy)"
                    cmd = subprocess.call(prox_exp+" ; python2.7 -m pip install matplotlib --user",shell=True)
                    if cmd == 0:
                        print "SUCCESS: Installation of matplotlib completed."
                    else:
                        print "ERROR: Impossible to install Matplotlib. Check connection/proxy adress/pip version."
                        a = raw_input("Press enter to quit")
                        sys.exit()
                except:
                    print "ERROR: Impossible to install Matplotlib. Check connection/proxy adress."
                    a = raw_input("Press enter to quit")
                    sys.exit()
            except ImportError:
                print "INFO: Pip not installed"
                try:
                    print "INFO: Trying to install xcode-select (proxy)"
                    cmd = subprocess.call(prox_exp+" ; xcode-select --install",shell=True)
                    if cmd == 0:
                        print "SUCCESS: Installation of xcode-select completed."
                    else:
                        print "WARNING: Impossible to install xcode-select. Check your connection."
                except OSError:
                    print "WARNING: Impossible to install xcode-select."
                try:
                    print "INFO: Trying to install pip using easy_install (proxy)"
                    cmd = subprocess.call(prox_exp+" ; sudo -E easy_install pip",shell=True)
                    if cmd == 0:
                        print "SUCCESS: Installation of pip completed."
                    else:
                        print "ERROR: Impossible to install pip. Check your connection."
                        # print "ERROR: Impossible to install Matplotlib. Check connection/proxy adress."
                        a = raw_input("Press enter to quit")
                        sys.exit()
                except OSError:
                    print "ERROR: Impossible to install pip"
                    a = raw_input("Press enter to quit")
                    sys.exit()
                try:
                    # print "INFO: Trying to install upgrade pip (proxy)"
                    # cmd = subprocess.call(prox_exp+" ; curl https://bootstrap.pypa.io/get-pip.py | python",shell=True)
                    # if cmd == 0:
                    #     print "SUCCESS: Pip upgraded."
                    # else:
                    #     print "ERROR: Impossible to upgrade pip."
                    print "INFO: Trying to install matplotlib using pip (proxy)"
                    cmd = subprocess.call(prox_exp+" ; python2.7 -m pip install matplotlib --user",shell=True)
                    if cmd == 0:
                        print "SUCCESS: Installation of matplotlib completed."
                    else:
                        print "ERROR: Impossible to install Matplotlib. Check connection/proxy adress/pip version."
                        a = raw_input("Press enter to quit")
                        sys.exit()
                except:
                    print "ERROR: Impossible to install Matplotlib. Check connection/proxy adress."
                    a = raw_input("Press enter to quit")
                    sys.exit()

a = raw_input("SUCCESS: Installation completed. Press enter to quit")
